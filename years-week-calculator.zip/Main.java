/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner red =new Scanner(System.in);
	    System.out.println("seconds: ");
	    long a=red.nextInt();
	    long hour=a/3600;
	    long remain=a%3600;
	    long minute=remain/60;
	    long seconds= remain%60;
	    /*System.out.println("number of hours : " +hour);
	    System.out.println("no of minute : " +minute);
	    System.out.println("seconds : " +seconds);*/
	    System.out.printf(hour+":",+minute+":",+seconds);
	}
}
