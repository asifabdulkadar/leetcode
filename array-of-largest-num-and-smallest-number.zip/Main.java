public class Main {
    public static void main(String[] args) {
        int[] n = {1,11,22,3,2,5,6,10,8};

        int s = n[0];
        int l = n[0];

        for (int i = 1; i < n.length; i++) {
            if (n[i] > l) {
                l = n[i];
            } else if (n[i] < s) {
                s = n[i];
            }
        }

        System.out.println("Largest number: " + l);
        System.out.println("Smallest number: " + s);
    }
}