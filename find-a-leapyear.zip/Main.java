import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
	    int a =2003;
	    if(a%4==0||(a%400==0&&a%100!=0))
	    {
	        System.out.println("leap");
	    }
	    else
	    {
	        System.out.println("not a leap year");
	    } 
	    
	}
}
