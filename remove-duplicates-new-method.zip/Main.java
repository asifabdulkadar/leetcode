import java.util.*;
public class Main
{
	public static void main(String[] args) {
	     int a[]={11,23,67,11,5,66,5};
	     Arrays.sort(a);
	     System.out.println();
	     for(int i=0;i<a.length;i++){
	          if(i==0||a[i]!=a[i-1]){
	               System.out.print(a[i]+"  ");
	               
	          }
	     }
	     
		System.out.println();
		System.out.println("Duplicate values :  ");
		for(int i=0;i<(a.length)-1;i++){
		     if(a[i]==a[i+1]){
		          System.out.println(a[i]+" ");		     }
		}
	
	}
}
