/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		int a[]={23,12,2,13,15,14,16};
		Scanner sc = new Scanner(System.in);
		int b= sc.nextInt();
		for(int i=0;i<a.length;i++){
		    
		    if (a[i]==b){
		        System.out.println("given Element is in the array :"+b);
		        break;
		    }
		    else{
		        System.out.println("there no longer number you've entered :"+b);
		        break;
		    }
		}
		
	}
}
