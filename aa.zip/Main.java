import java.util.*;

public class CharacterCheck {

    public static String checkCharacter(char character) {
        // Check if the character is an alphabet
        if (Character.isAlphabetic(character)) {
            // Check if the character is a vowel
            char lowerChar = Character.toLowerCase(character); // Convert to lowercase for easy comparison
            if (lowerChar == 'a' || lowerChar == 'e' || lowerChar == 'i' || lowerChar == 'o' || lowerChar == 'u') {
                return character + " is a vowel.";
            } else {
                return character + " is a consonant.";
            }
        } else {
            return character + " is not an alphabet.";
        }
    }

    public static void main(String[] args) {
        // Test cases
        System.out.println(checkCharacter('A'));  // Should print "A is a vowel."
        System.out.println(checkCharacter('b'));  // Should print "b is a consonant."
        System.out.println(checkCharacter('1'));  // Should print "1 is not an alphabet."
    }
}
